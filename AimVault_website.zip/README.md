# AimVault
Ready-to-run static prototype for a Valorant crosshair database.

Open `index.html` directly or serve the folder with a static server.

Features:
- AimVault dark gaming UI
- Curated vs Community crosshairs
- Recently Added community submissions
- Add Crosshair with live code validation/preview
- Dynamic canvas renderer from stored Valorant code
- Search/filter/pagination
- Detail pages and Copy Code
- Generator
- Optional Supabase integration

For production Supabase, replace the empty `SUPABASE_URL` and `SUPABASE_ANON_KEY` in `index.html`. Never use a service-role key in frontend code.

Important: the renderer is modular and parses the common Valorant code fields. Riot can change the code format, so any newly introduced parameters should be added to `parseCode()`/`draw()`.
